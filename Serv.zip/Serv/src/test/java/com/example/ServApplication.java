package com.example;

public record ServApplication() {
}
