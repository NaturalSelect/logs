-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: database
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `files_tb`
--

use `database`;

DROP TABLE IF EXISTS `files_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `files_tb` (
                            `url` varchar(256) NOT NULL COMMENT '文件访问路径',
                            `name` varchar(256) NOT NULL,
                            `file_type` int NOT NULL COMMENT '映射到`meta_file_types`',
                            `isOrigin` tinyint(1) NOT NULL DEFAULT '0' COMMENT '存储路径是否是远程路径',
                            `path` varchar(256) NOT NULL COMMENT '存储路径',
                            `update_time` datetime NOT NULL COMMENT '上传日期',
                            `is_origin` bit(1) DEFAULT NULL,
                            PRIMARY KEY (`url`),
                            KEY `file_type` (`file_type`),
                            CONSTRAINT `files_tb_ibfk_1` FOREIGN KEY (`file_type`) REFERENCES `meta_file_types_tb` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files_tb`
--

LOCK TABLES `files_tb` WRITE;
/*!40000 ALTER TABLE `files_tb` DISABLE KEYS */;
INSERT INTO `files_tb` VALUES ('/file/1-1.txt','1-1.txt',3,0,'D:\\.VDB\\1-1.txt','2024-04-10 13:00:00',NULL),('/file/1-2.txt','1-2.txt',3,0,'D:\\.VDB\\1-2.txt','2024-04-10 13:10:00',NULL),('/file/123.txt','123.txt',3,0,'D:\\.VDB\\123.txt','2024-04-10 13:11:00',NULL),('/file/13b142d5-8f0f-4b45-aab3-5be31c57d7b1.jpg','am.jpg',1,0,'D:\\.VDB\\13b142d5-8f0f-4b45-aab3-5be31c57d7b1.jpg','2024-05-16 02:58:35',_binary '\0'),('/file/2-1.txt','2-1.txt',3,0,'D:\\.VDB\\2-1.txt','2024-04-10 13:20:00',NULL),('/file/986cda52-1a0f-4525-8690-52e6b8b0df1f.xlsx','aa.xlsx',2,0,'D:\\.VDB\\986cda52-1a0f-4525-8690-52e6b8b0df1f.xlsx','2024-05-16 03:08:55',_binary '\0'),('/file/cat.jpeg','cat.jpeg',1,0,'D:\\.VDB\\cat.jpeg','2024-04-10 13:00:00',NULL);
/*!40000 ALTER TABLE `files_tb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_tb`
--

DROP TABLE IF EXISTS `group_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_tb` (
                            `gid` int NOT NULL AUTO_INCREMENT,
                            `super_gid` int DEFAULT NULL COMMENT '嵌套组时，上层gid',
                            `group_name` varchar(128) NOT NULL COMMENT '组名称（例如"成都信息工程大学"）',
                            `group_type` int NOT NULL COMMENT '组类型，映射到`meta_group_type`（例如"校方老师组"）',
                            `tid` int DEFAULT NULL,
                            `inter_name` varchar(255) DEFAULT NULL,
                            PRIMARY KEY (`gid`),
                            KEY `group_type` (`group_type`),
                            KEY `super_gid` (`super_gid`),
                            CONSTRAINT `group_tb_ibfk_1` FOREIGN KEY (`group_type`) REFERENCES `meta_group_type_tb` (`id`),
                            CONSTRAINT `group_tb_ibfk_2` FOREIGN KEY (`super_gid`) REFERENCES `group_tb` (`gid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_tb`
--

LOCK TABLES `group_tb` WRITE;
/*!40000 ALTER TABLE `group_tb` DISABLE KEYS */;
INSERT INTO `group_tb` VALUES (1,NULL,'某 LTD 企业',2),(2,NULL,'CUIT 成都信息工程大学教师组',3),(3,NULL,'CUIT 成都信息工程大学学生组',4),(4,3,'CUIT 快乐地实习小组1',5),(5,3,'CUIT 快乐地实习小组2',5),(6,3,'CUIT 快乐地实习小组3',5),(7,NULL,'空的学生组',4),(8,7,'空组中的小组',5);
/*!40000 ALTER TABLE `group_tb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inter_tb`
--

DROP TABLE IF EXISTS `inter_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inter_tb` (
                            `tid` int NOT NULL AUTO_INCREMENT COMMENT 'id',
                            `inter_type` varchar(50) DEFAULT NULL COMMENT '实习类型标识',
                            `inter_name` varchar(255) DEFAULT NULL COMMENT '实习岗位名称',
                            `industry` varchar(255) DEFAULT NULL COMMENT '所属行业',
                            `create_time` datetime DEFAULT NULL COMMENT '创建时间',
                            `update_time` datetime DEFAULT NULL COMMENT '修改时间',
                            PRIMARY KEY (`tid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inter_tb`
--

LOCK TABLES `inter_tb` WRITE;
/*!40000 ALTER TABLE `inter_tb` DISABLE KEYS */;
INSERT INTO `inter_tb` VALUES (2,'java','后端开发','互联网','2024-05-17 15:02:34','2024-05-17 15:02:36'),(3,'python','数据分析','互联网','2024-05-17 15:03:23','2024-05-17 15:03:25'),(4,'vue','前端开发','互联网','2024-05-17 15:03:42','2024-05-17 15:03:44');
/*!40000 ALTER TABLE `inter_tb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meta_file_types_tb`
--

DROP TABLE IF EXISTS `meta_file_types_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meta_file_types_tb` (
                                      `id` int NOT NULL AUTO_INCREMENT,
                                      `type` varchar(32) NOT NULL,
                                      PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta_file_types_tb`
--

LOCK TABLES `meta_file_types_tb` WRITE;
/*!40000 ALTER TABLE `meta_file_types_tb` DISABLE KEYS */;
INSERT INTO `meta_file_types_tb` VALUES (1,'PIC'),(2,'FMT'),(3,'TXT'),(4,'ZIP');
/*!40000 ALTER TABLE `meta_file_types_tb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meta_group_type_tb`
--

DROP TABLE IF EXISTS `meta_group_type_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meta_group_type_tb` (
                                      `id` int NOT NULL AUTO_INCREMENT,
                                      `type` varchar(32) NOT NULL,
                                      PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta_group_type_tb`
--

LOCK TABLES `meta_group_type_tb` WRITE;
/*!40000 ALTER TABLE `meta_group_type_tb` DISABLE KEYS */;
INSERT INTO `meta_group_type_tb` VALUES (1,'未知'),(2,'企业导师'),(3,'校方老师'),(4,'校方学生'),(5,'实训小组');
/*!40000 ALTER TABLE `meta_group_type_tb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meta_inter_type_tb`
--

DROP TABLE IF EXISTS `meta_inter_type_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meta_inter_type_tb` (
                                      `id` int NOT NULL,
                                      `name` varchar(255) DEFAULT NULL,
                                      PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta_inter_type_tb`
--

LOCK TABLES `meta_inter_type_tb` WRITE;
/*!40000 ALTER TABLE `meta_inter_type_tb` DISABLE KEYS */;
/*!40000 ALTER TABLE `meta_inter_type_tb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meta_permissions_tb`
--

DROP TABLE IF EXISTS `meta_permissions_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meta_permissions_tb` (
                                       `id` int NOT NULL AUTO_INCREMENT,
                                       `type` varchar(32) NOT NULL,
                                       PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta_permissions_tb`
--

LOCK TABLES `meta_permissions_tb` WRITE;
/*!40000 ALTER TABLE `meta_permissions_tb` DISABLE KEYS */;
INSERT INTO `meta_permissions_tb` VALUES (1,'超级管理员|小组长'),(2,'管理员'),(3,'成员|组员');
/*!40000 ALTER TABLE `meta_permissions_tb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meta_sex_tb`
--

DROP TABLE IF EXISTS `meta_sex_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meta_sex_tb` (
                               `id` int NOT NULL AUTO_INCREMENT,
                               `type` varchar(32) NOT NULL,
                               PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta_sex_tb`
--

LOCK TABLES `meta_sex_tb` WRITE;
/*!40000 ALTER TABLE `meta_sex_tb` DISABLE KEYS */;
INSERT INTO `meta_sex_tb` VALUES (1,'未知'),(2,'男'),(3,'女'),(4,'保密');
/*!40000 ALTER TABLE `meta_sex_tb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meta_status_tb`
--

DROP TABLE IF EXISTS `meta_status_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meta_status_tb` (
                                  `id` int NOT NULL AUTO_INCREMENT,
                                  `type` varchar(32) NOT NULL,
                                  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta_status_tb`
--

LOCK TABLES `meta_status_tb` WRITE;
/*!40000 ALTER TABLE `meta_status_tb` DISABLE KEYS */;
INSERT INTO `meta_status_tb` VALUES (1,'无状态'),(2,'忙碌'),(3,'美滋滋'),(4,'自信满满'),(5,'赶DDL'),(6,'一起努力'),(7,'emo中'),(8,'想静静');
/*!40000 ALTER TABLE `meta_status_tb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_content_tb`
--

DROP TABLE IF EXISTS `project_content_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_content_tb` (
                                      `pid` int NOT NULL,
                                      `title` varchar(128) NOT NULL,
                                      `content` varchar(1024) NOT NULL,
                                      `s1ddl` datetime NOT NULL,
                                      `s2ddl` datetime NOT NULL,
                                      `s3ddl` datetime NOT NULL,
                                      `tid` int DEFAULT NULL COMMENT '实习岗位外键',
                                      KEY `pid` (`pid`),
                                      KEY `project_content_tb_ibfk_2` (`tid`),
                                      CONSTRAINT `project_content_tb_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `project_tb` (`pid`),
                                      CONSTRAINT `project_content_tb_ibfk_2` FOREIGN KEY (`tid`) REFERENCES `inter_tb` (`tid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_content_tb`
--

LOCK TABLES `project_content_tb` WRITE;
/*!40000 ALTER TABLE `project_content_tb` DISABLE KEYS */;
INSERT INTO `project_content_tb` VALUES (1,'快乐地管理系统','这是一个快乐地管理系统，无论如何它看上去都很快乐。这个实习的内容就是要做一个快乐地管理系统，这个系统要快乐，要管理，要系统，启动！','2024-04-20 13:00:00','2024-04-30 13:00:00','2024-05-10 13:00:00',2),(2,'空项目','这是一个空的项目，空的，项目。','2024-04-10 13:00:00','2024-04-10 13:00:00','2024-04-10 13:00:00',3);
/*!40000 ALTER TABLE `project_content_tb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_files_tb`
--

DROP TABLE IF EXISTS `project_files_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_files_tb` (
                                    `pid` int NOT NULL COMMENT '哪个项目的文件',
                                    `gid` int NOT NULL COMMENT '哪个小组的文件',
                                    `uid` int NOT NULL COMMENT '上传者',
                                    `url` varchar(256) NOT NULL COMMENT '映射到`files`',
                                    `stage` int NOT NULL COMMENT '1-3: 开题、中期、最终',
                                    `score` int DEFAULT NULL,
                                    KEY `pid` (`pid`),
                                    KEY `url` (`url`),
                                    KEY `uid` (`uid`),
                                    KEY `gid` (`gid`),
                                    CONSTRAINT `project_files_tb_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `project_tb` (`pid`),
                                    CONSTRAINT `project_files_tb_ibfk_2` FOREIGN KEY (`url`) REFERENCES `files_tb` (`url`),
                                    CONSTRAINT `project_files_tb_ibfk_3` FOREIGN KEY (`uid`) REFERENCES `role_tb` (`uid`),
                                    CONSTRAINT `project_files_tb_ibfk_4` FOREIGN KEY (`gid`) REFERENCES `group_tb` (`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_files_tb`
--

LOCK TABLES `project_files_tb` WRITE;
/*!40000 ALTER TABLE `project_files_tb` DISABLE KEYS */;
INSERT INTO `project_files_tb` VALUES (1,4,3,'/file/1-1.txt',1,95),(1,5,8,'/file/1-2.txt',1,85),(1,6,13,'/file/2-1.txt',1,60),(1,6,13,'/file/123.txt',2,NULL);
/*!40000 ALTER TABLE `project_files_tb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_tb`
--

DROP TABLE IF EXISTS `project_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_tb`
 (

    `pid` int not null auto_increment primary key,
    `gid` int not null comment '对没错，就是`group`套壳',
    foreign key (`gid`) references `group_tb` (`gid`)
);


LOCK TABLES `project_tb` WRITE;
/*!40000 ALTER TABLE `project_tb` DISABLE KEYS */;
INSERT INTO `project_tb` VALUES (1,3),(2,7);
/*!40000 ALTER TABLE `project_tb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_group_tb`
--

DROP TABLE IF EXISTS `role_group_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_group_tb` (
                                 `uid` int NOT NULL,
                                 `gid` int NOT NULL,
                                 `permission` int NOT NULL COMMENT '用户在组中的权限，映射到`meta_permissions`',
                                 KEY `permission` (`permission`),
                                 KEY `uid` (`uid`),
                                 KEY `gid` (`gid`),
                                 CONSTRAINT `role_group_tb_ibfk_1` FOREIGN KEY (`permission`) REFERENCES `meta_permissions_tb` (`id`),
                                 CONSTRAINT `role_group_tb_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `role_tb` (`uid`),
                                 CONSTRAINT `role_group_tb_ibfk_3` FOREIGN KEY (`gid`) REFERENCES `group_tb` (`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_group_tb`
--

LOCK TABLES `role_group_tb` WRITE;
/*!40000 ALTER TABLE `role_group_tb` DISABLE KEYS */;
INSERT INTO `role_group_tb` VALUES (1,1,1),(2,2,1),(1,3,2),(1,7,2),(2,3,1),(2,7,1),(3,3,3),(4,3,3),(5,3,3),(6,3,3),(7,3,3),(8,3,3),(9,3,3),(10,3,3),(11,3,3),(12,3,3),(13,3,3),(14,3,3),(15,3,3),(16,3,3),(17,3,3),(18,7,3),(3,4,1),(4,4,3),(5,4,3),(6,4,3),(7,4,3),(8,5,1),(9,5,3),(10,5,3),(11,5,3),(12,5,3),(13,6,1),(14,6,3),(15,6,3),(18,8,1);
/*!40000 ALTER TABLE `role_group_tb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_info_tb`
--

DROP TABLE IF EXISTS `role_info_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_info_tb` (
                                `uid` int NOT NULL,
                                `avatar_url` varchar(256) DEFAULT NULL COMMENT '头像路径，映射到`images`',
                                `sex` int NOT NULL DEFAULT '1' COMMENT '性别，映射到`meta_sex`',
                                `introduction` varchar(256) NOT NULL DEFAULT '系统原装签名，给每一位小可爱~' COMMENT '个性签名',
                                `email` varchar(256) NOT NULL DEFAULT '' COMMENT '邮箱，我只让写一个',
                                `whoami` varchar(1024) NOT NULL DEFAULT '' COMMENT '个人简介',
                                `status` int NOT NULL DEFAULT '1' COMMENT '当前状态，映射到`meta_status`',
                                KEY `sex` (`sex`),
                                KEY `status` (`status`),
                                KEY `uid` (`uid`),
                                KEY `avatar_url` (`avatar_url`),
                                CONSTRAINT `role_info_tb_ibfk_1` FOREIGN KEY (`sex`) REFERENCES `meta_sex_tb` (`id`),
                                CONSTRAINT `role_info_tb_ibfk_2` FOREIGN KEY (`status`) REFERENCES `meta_status_tb` (`id`),
                                CONSTRAINT `role_info_tb_ibfk_3` FOREIGN KEY (`uid`) REFERENCES `role_tb` (`uid`),
                                CONSTRAINT `role_info_tb_ibfk_4` FOREIGN KEY (`avatar_url`) REFERENCES `files_tb` (`url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_info_tb`
--

LOCK TABLES `role_info_tb` WRITE;
/*!40000 ALTER TABLE `role_info_tb` DISABLE KEYS */;
INSERT INTO `role_info_tb` VALUES (1,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(2,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(3,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(4,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(5,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(6,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(7,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(8,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(9,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(10,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(11,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(12,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(13,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(14,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(15,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(16,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(17,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1),(18,'/file/cat.jpeg',1,'系统原装签名，给每一位小可爱~','','',1);
/*!40000 ALTER TABLE `role_info_tb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_tb`
--

DROP TABLE IF EXISTS `role_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_tb` (
                           `uid` int NOT NULL AUTO_INCREMENT,
                           `phone` varchar(20) NOT NULL COMMENT '电话号码',
                           `nickname` varchar(64) NOT NULL COMMENT '昵称',
                           `token` varchar(256) NOT NULL COMMENT '用于单点登录的凭据',
                           `belong` int DEFAULT NULL COMMENT '当前用户的归属，映射到`group(gid)`',
                           PRIMARY KEY (`uid`),
                           UNIQUE KEY `phone` (`phone`),
                           KEY `belong` (`belong`),
                           CONSTRAINT `role_tb_ibfk_1` FOREIGN KEY (`belong`) REFERENCES `group_tb` (`gid`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_tb`
--

LOCK TABLES `role_tb` WRITE;
/*!40000 ALTER TABLE `role_tb` DISABLE KEYS */;
INSERT INTO `role_tb` VALUES (1,'12345600','张布斯','1946',1),(2,'12345601','李老师','5126',2),(3,'12345670','王五同学','',3),(4,'12345671','赵六同学','',3),(5,'12345672','钱七同学','',3),(6,'12345673','孙八同学','8687',3),(7,'12345674','周九同学','',3),(8,'12345675','吴十同学','',3),(9,'12345676','郑十一同学','',3),(10,'12345677','周十二同学','',3),(11,'12345678','吴十三同学','',3),(12,'12345679','郑十四同学','',3),(13,'12345680','周十五同学','',3),(14,'12345681','吴十六同学','',3),(15,'12345682','郑十七同学','6735',3),(16,'12345683','周十八同学','',3),(17,'12345684','吴十九同学','',7),(18,'12345685','郑二十同学','',7);
/*!40000 ALTER TABLE `role_tb` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-17 16:56:58
