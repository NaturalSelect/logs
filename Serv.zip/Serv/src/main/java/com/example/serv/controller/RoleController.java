package com.example.serv.controller;

import com.example.serv.dao.meta.MetaGroupTypeDao;
import com.example.serv.entity.*;
import com.example.serv.entity.meta.MetaGroupType;
import com.example.serv.service.GroupService;
import com.example.serv.service.RoleGroupService;
import com.example.serv.service.RoleInfoService;
import com.example.serv.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;
import java.util.Random;

@RestController
@RequestMapping("role")
public class RoleController {
    @Autowired
    private RoleService roleService;
    @Autowired
    private RoleInfoService roleInfoService;
    @Autowired
    private GroupService groupService;
    @Autowired
    private RoleGroupService roleGroupService;
    @Autowired
    private MetaGroupTypeDao metaGroupTypeDao;

    @RequestMapping("/all")
    public List<Role> getAll() {
        return roleService.getAll();
    }

    //增加一个
    @RequestMapping("/insert")
    public Role insert(@RequestBody Role item) {
        return roleService.insert(item);
    }

    //删除一个
    @RequestMapping("/delete")
    public String delete(@RequestBody Role item) {
        roleService.delete(item);
        return "";
    }

    //修改一个
    @RequestMapping("/update")
    public Role update(@RequestBody Role item) {
        //增改是同一个逻辑
        return insert(item);
    }

    @RequestMapping("/requestCode")
    public String requestCode(@RequestBody Role hasPhone) {
        String phone = hasPhone.getPhone();
        Role role = roleService.findByPhone(phone);
        if (role == null) {
            //注册
            Integer type = hasPhone.getBelong();
            if (type == null || (type != 2 && type != 3)) {
                return "error";
            }
            Group group = new Group();
            group.setGroupName("");
            group.setGroupType(type);
            group = groupService.insert(group);
            Optional<MetaGroupType> types = metaGroupTypeDao.findById(type);
            group.setGroupName((types.isPresent() ? types.get().getType() : "群组") + group.getGid());
            group = groupService.insert(group);
            role = new Role();
            role.setBelong(group.getGid());
            role.setNickname(phone);
            role.setPhone(phone);
            role.setToken("");
            role = roleService.insert(role);
            RoleGroup roleGroup = new RoleGroup();
            UPKs.RoleGroupUPK upk = new UPKs.RoleGroupUPK();
            upk.setUid(role.getUid());
            upk.setGid(group.getGid());
            roleGroup.setKeys(upk);
            roleGroup.setPermission(1);
            roleGroupService.insert(roleGroup);
            Role finalRole = role;
            RoleInfo roleInfo = new RoleInfo();
            roleInfo.setUid(finalRole.getUid());
            roleInfo.setAvatarUrl("/file/cat.jpeg");
            roleInfo.setEmail("");
            roleInfo.setSex(1);
            roleInfo.setStatus(1);
            roleInfo.setIntroduction("");
            roleInfo.setWhoami("");
            roleInfoService.insert(roleInfo);
        }
        Random random = new Random();
        String ans = "";
        ans += random.nextInt(0, 10);
        ans += random.nextInt(0, 10);
        ans += random.nextInt(0, 10);
        ans += random.nextInt(0, 10);
        role.setToken(ans);
        roleService.insert(role);
        System.err.println("手机号:" + phone + "; 验证码：" + ans);
        return "ok";
    }
}
