package com.example.serv.controller;

import com.example.serv.entity.Group;
import com.example.serv.service.GroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/groups")
public class GroupController {
    @Autowired
    private GroupService groupService;

    //查询所有
    @RequestMapping("/all")
    public List<Group> getAll() {
        return groupService.getAll();
    }

    //增加一个
    @RequestMapping("/insert")
    public Group insert(@RequestBody Group group) {
        return groupService.insert(group);
    }

    //删除一个
    @RequestMapping("/delete")
    public String delete(@RequestBody Group group) {
        groupService.delete(group);
        return "";
    }

    //修改一个
    @RequestMapping("/update")
    public Group update(@RequestBody Group group) {
        //增改是同一个逻辑
        return insert(group);
    }
}
