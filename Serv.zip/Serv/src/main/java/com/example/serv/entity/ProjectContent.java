package com.example.serv.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Data
@Entity(name = "project_content_tb")
public class ProjectContent {
    @Id
    @Column(name = "pid")
    Integer pid;
    @Column(name = "title")
    String title;
    @Column(name = "content")
    String content;
    @Column(name = "tid")
    Integer tid;
    @Column(name = "s1ddl")
    Date s1ddl;
    @Column(name = "s2ddl")
    Date s2ddl;
    @Column(name = "s3ddl")
    Date s3ddl;
}
