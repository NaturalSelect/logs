package com.example.serv.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import lombok.Data;

@Data
@Entity(name = "role_group_tb")
public class RoleGroup {
    @EmbeddedId
    UPKs.RoleGroupUPK keys;
    @Column(name = "permission")
    Integer permission;
}
