package com.example.serv.dao.meta;

import com.example.serv.entity.meta.MetaGroupType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MetaGroupTypeDao extends JpaRepository<MetaGroupType, Integer> {
}
