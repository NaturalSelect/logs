package com.example.serv.controller;

import com.example.serv.entity.ProjectContent;
import com.example.serv.service.ProjectContentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/project_content")
public class ProjectContentController {
    @Autowired
    private ProjectContentService projectContentService;

    @RequestMapping("/all")
    public List<ProjectContent> getAll() {
        return projectContentService.getAll();
    }
    //增加一个  
    @RequestMapping("/insert")
    public ProjectContent insert(@RequestBody ProjectContent projectContent) {
       return projectContentService.insert(projectContent);
    }

    //删除一个
    @RequestMapping("/delete")
    public String delete(@RequestBody ProjectContent projectContent) {
        projectContentService.delete(projectContent);
        return "";
    }

    //修改一个
    @RequestMapping("/update")
    public ProjectContent update(@RequestBody ProjectContent projectContent) {
        //增改是同一个逻辑
        return insert(projectContent);
    }
}
