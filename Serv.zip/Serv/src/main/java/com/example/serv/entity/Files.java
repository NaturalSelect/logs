package com.example.serv.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

import java.util.Date;

@Data
@Entity(name = "files_tb")
public class Files {
    @Id
    @Column(name = "url")
    String url;
    @Column(name = "name")
    String name;
    @Column(name = "file_type")
    Integer fileType;
    @Column(name = "isOrigin")
    Boolean isOrigin;
    @Column(name = "path")
    String path;
    @Column(name = "update_time")
    Date updateTime;
}
