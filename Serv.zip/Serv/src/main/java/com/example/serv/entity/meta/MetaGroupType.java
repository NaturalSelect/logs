package com.example.serv.entity.meta;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity(name = "meta_group_type_tb")
public class MetaGroupType {
    @Id
    @Column(name = "id")
    Integer id;
    @Column(name = "type")
    String type;
}
