package com.example.serv.service.impl;

import com.example.serv.dao.ProjectDao;
import com.example.serv.entity.Project;
import com.example.serv.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectServiceImpl implements ProjectService {
    @Autowired
    private ProjectDao projectDao;

    @Override
    public List<Project> getAll() {
        return projectDao.findAll();
    }

    @Override
    public Project insert(Project item) {
        return projectDao.save(item);
    }

    @Override
    public void delete(Project item) {
        projectDao.delete(item);
    }
}
