package com.example.serv.dao.meta;

import com.example.serv.entity.meta.MetaSex;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MetaSexDao extends JpaRepository<MetaSex, Integer> {
}
