package com.example.serv.service.impl;

import com.example.serv.dao.FilesDao;
import com.example.serv.entity.Files;
import com.example.serv.service.FilesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FilesServiceImpl implements FilesService {
    @Autowired
    private FilesDao filesDao;

    @Override
    public List<Files> getAllFiles() {
        return filesDao.findAll();
    }

    @Override
    public Files getFileByUrl(String url) {
        return filesDao.findById(url).orElse(null);
    }

    @Override
    public Files saveFile(Files files) {
        return filesDao.save(files);
    }
}
