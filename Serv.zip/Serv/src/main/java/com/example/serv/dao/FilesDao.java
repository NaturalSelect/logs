package com.example.serv.dao;

import com.example.serv.entity.Files;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FilesDao extends JpaRepository<Files, String> {
}
