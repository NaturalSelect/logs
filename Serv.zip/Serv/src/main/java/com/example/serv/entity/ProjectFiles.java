package com.example.serv.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity(name = "project_files_tb")
public class ProjectFiles {
    @EmbeddedId
    UPKs.ProjectFilesUPK keys;
    @Column(name = "stage")
    Integer stage;//阶段
    @Column(name = "score")
    Integer score;//分数
}
