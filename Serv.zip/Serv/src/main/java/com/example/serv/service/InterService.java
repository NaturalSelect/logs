package com.example.serv.service;

import com.example.serv.entity.Group;
import com.example.serv.entity.Inter;

import java.util.List;

public interface InterService {
    /**
     *新增实习岗位
     */
    Inter insert(Inter inter);
    /**
     * 删除实习岗位
     */
    void delete(Integer tid);

    /**
     * 查询实习岗位
     */
    List<Inter> getAll();
}
