package com.example.serv.service.impl;

import com.example.serv.dao.GroupDao;
import com.example.serv.entity.Group;
import com.example.serv.service.GroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GroupServiceImpl implements GroupService {
    @Autowired
    private GroupDao groupDao;

    @Override
    public List<Group> getAll() {
        return groupDao.findAll();
    }

    @Override
    public Group insert(Group group) {
        return groupDao.save(group);
    }

    @Override
    public void delete(Group group) {
        groupDao.delete(group);
    }
}
