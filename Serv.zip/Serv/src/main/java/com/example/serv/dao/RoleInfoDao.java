package com.example.serv.dao;

import com.example.serv.entity.RoleInfo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleInfoDao extends JpaRepository<RoleInfo, Integer> {
}
