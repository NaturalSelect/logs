package com.example.serv.controller;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

@Controller
public class FileDownloadController {

    @GetMapping("/download/{fileName}")
    public void downloadFile(@PathVariable String fileName, HttpServletResponse response) {
        // 设置文件的路径
        String filePath = "D:\\.VDB\\" +  fileName;
        File file = new File(filePath);

        if (file.exists()) {
            try (FileInputStream fis = new FileInputStream(file)) {
                response.setContentType("application/octet-stream");
                response.setCharacterEncoding("utf-8");
                String headerValue = "attachment; filename=" + file.getName();
                response.addHeader("Content-Disposition", headerValue);
                response.setContentLength((int) file.length());

                OutputStream os = response.getOutputStream();
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = fis.read(buffer)) != -1) {
                    os.write(buffer, 0, bytesRead);
                }
                os.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            // 如果文件不存在，返回错误信息或处理逻辑
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
        }
    }
}
