package com.example.serv.service;

import com.example.serv.entity.Role;

import java.util.List;

public interface RoleService {
    List<Role> getAll();

    Role insert(Role item);

    void delete(Role item);

    Role findByPhone(String phone);
}
