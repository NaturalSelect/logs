package com.example.serv.dao.meta;

import com.example.serv.entity.meta.MetaFileTypes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MetaFileTypesDao extends JpaRepository<MetaFileTypes, Integer> {
}
