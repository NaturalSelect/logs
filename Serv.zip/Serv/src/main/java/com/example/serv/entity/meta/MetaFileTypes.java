package com.example.serv.entity.meta;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity(name = "meta_file_types_tb")
public class MetaFileTypes {
    @Id
    @Column(name = "id")
    Integer id;
    @Column(name = "type")
    String type;
}
