package com.example.serv.service;

import com.example.serv.entity.RoleGroup;

import java.util.List;

public interface RoleGroupService {
    List<RoleGroup> getAll();

    RoleGroup insert(RoleGroup item);

    void delete(RoleGroup item);
}
