package com.example.serv.controller;

import com.example.serv.entity.Project;
import com.example.serv.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/project")
public class ProjectController {
    @Autowired
    private ProjectService projectService;

    @RequestMapping("/all")
    public List<Project> getAll() {
        return projectService.getAll();
    }

    //增加一个
    @RequestMapping("/insert")
    public Project insert(@RequestBody Project item) {
        return projectService.insert(item);
    }

    //删除一个
    @RequestMapping("/delete")
    public String delete(@RequestBody Project item) {
        projectService.delete(item);
        return "";
    }

    //修改一个
    @RequestMapping("/update")
    public Project update(@RequestBody Project item) {
        //增改是同一个逻辑
        return insert(item);
    }
}
