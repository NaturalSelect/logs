package com.example.serv.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.*;

import java.io.Serializable;

public class UPKs {
    @Builder
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Embeddable
    @EqualsAndHashCode
    public static class ProjectFilesUPK implements Serializable {
        @Column(name = "pid")
        Integer pid;
        @Column(name = "gid")
        Integer gid;
        @Column(name = "uid")
        Integer uid;
        @Column(name = "url")
        String url;
    }

    @Builder
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Embeddable
    @EqualsAndHashCode
    public static class RoleGroupUPK implements Serializable {
        @Column(name = "uid")
        Integer uid;
        @Column(name = "gid")
        Integer gid;
    }
}
