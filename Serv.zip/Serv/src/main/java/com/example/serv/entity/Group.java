package com.example.serv.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity(name = "group_tb")
public class Group {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "gid")
    Integer gid;
    @Column(name = "super_gid")
    Integer superGid;
    @Column(name = "group_name")
    String groupName;
    @Column(name = "group_type")
    Integer groupType;
    /**
     * id
     */
    @Column(name = "tid")
    private Integer tid;
    /**
     * 实习岗位名称
     */
    @Column(name = "inter_name")
    private String interName;
}
