package com.example.serv.dao;

import com.example.serv.entity.ProjectFiles;
import com.example.serv.entity.UPKs;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectFilesDao extends JpaRepository<ProjectFiles, UPKs.ProjectFilesUPK> {
}
