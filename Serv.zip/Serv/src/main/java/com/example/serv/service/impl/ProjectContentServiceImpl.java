package com.example.serv.service.impl;

import com.example.serv.dao.ProjectContentDao;
import com.example.serv.entity.ProjectContent;
import com.example.serv.service.ProjectContentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectContentServiceImpl implements ProjectContentService {
    @Autowired
    private ProjectContentDao projectContentDao;

    @Override
    public List<ProjectContent> getAll() {
        return projectContentDao.findAll();
    }

    @Override
    public ProjectContent insert(ProjectContent projectContent) {
        return projectContentDao.save(projectContent);
    }

    @Override
    public void delete(ProjectContent projectContent) {
        projectContentDao.delete(projectContent);
    }
}
