package com.example.serv.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity(name = "project_tb")
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "pid")
    Integer pid;
    @Column(name = "gid")
    Integer gid;
}
