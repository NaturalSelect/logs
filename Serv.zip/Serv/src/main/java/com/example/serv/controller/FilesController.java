package com.example.serv.controller;

import com.example.serv.entity.Files;
import com.example.serv.service.FilesService;
import jakarta.servlet.http.HttpServletResponse;
import lombok.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Controller
@RequestMapping("/file")
public class FilesController {
    @Autowired
    private FilesService filesService;

    private static final String filepath = "D:\\.VDB\\";

    @ResponseBody
    @RequestMapping("/all")
    public List<Files> getAll() {
        return filesService.getAllFiles();
    }
    @ResponseBody
    @RequestMapping("/upload")
    public String upload(@RequestParam("file") MultipartFile uploadFile) {
        String uuidName = UUID.randomUUID().toString();
        List<String> pic = new ArrayList<>() {{
            add("xbm");
            add("tif");
            add("pjp");
            add("jpg");
            add("jpeg");
            add("ico");
            add("tiff");
            add("gif");
            add("svg");
            add("svgz");
            add("jfif");
            add("webp");
            add("png");
            add("bmp");
            add("pjpeg");
            add("avif");
        }};
        List<String> fmt = new ArrayList<>() {{
            add("doc");
            add("docs");
            add("ppt");
            add("pptx");
            add("xls");
            add("xlsx");
            add("vsd");
            add("vsdx");
            add("odt");
            add("ods");
            add("odp");
            add("odg");
            add("pdf");
            add("ps");
            add("rtf");
            add("tex");
            add("latex");
            add("md");
            add("markdown");
            add("xml");
            add("xhtml");
            add("html");
            add("htm");
            add("fb2");
            add("epub");
        }};
        List<String> zip = new ArrayList<>() {{
            add("zip");
            add("rar");
            add("tar");
            add("gz");
            add("tar.gz");
            add("bz2");
            add("tar.bz2");
            add("xz");
            add("tar.xz");
            add("7z");
            add("tar.7z");
            add("iso");
        }};
        if (uploadFile == null || uploadFile.isEmpty()) {
            System.err.println("文件不存在");
            return "";
        }
        String name = uploadFile.getOriginalFilename();
        if (name == null || name.isEmpty()) {
            name = uuidName;
            System.err.println("重命名为: " + name);
        }
        String[] illegalCharacters = new String[]{
                "\\", "/", ":", "*", "?", "\"", "<", ">", "|"
        };
        for (String s : illegalCharacters) {
            if (name.contains(s)) {//存在非法字符串
                System.err.println("存在非法字符串");
                System.err.println("name: " + name);
                return "";
            }
        }
        String regexPattern = ".+\\.tar\\.(?i)(" + String.join("|", zip) + ")";
        Pattern pattern = Pattern.compile(regexPattern);
        Matcher matcher = pattern.matcher(name);
        String suffix;
        int fileType;
        if (matcher.matches()) {//匹配成功，是tar.xx
            suffix = name.substring(name.lastIndexOf(".tar.") + 1);
            fileType = 4;
        } else {
            suffix = name.substring(name.lastIndexOf(".") + 1);
            if (pic.contains(suffix)) {
                fileType = 1;
            } else if (fmt.contains(suffix)) {
                fileType = 2;
            } else if (zip.contains(suffix)) {
                fileType = 4;
            } else {
                fileType = 3;
            }
        }
        String fileName = String.format("%s.%s", uuidName, suffix);
        String path = filepath + fileName;
        String url = "/file/" + fileName;
        Files files = new Files();
        files.setName(name);
        files.setFileType(fileType);
        files.setPath(path);
        files.setUrl(url);
        files.setIsOrigin(false);
        files.setUpdateTime(Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant()));
        System.err.println(files);
        try {
            uploadFile.transferTo(new File(path));
            filesService.saveFile(files);
            return url;
        } catch (IOException e) {
            System.err.println(e.getMessage());
            return "";
        }
    }

    @RequestMapping("/{subUrl}")
    public void download(@PathVariable String subUrl, HttpServletResponse response) {
        subUrl = "/file/" + subUrl;
        Files fileInfo = filesService.getFileByUrl(subUrl);
        if (fileInfo == null) {
            return;
        }
        File file = new File(fileInfo.getPath());
        if (!file.exists()) {
            return;
        }
        byte[] buffer = new byte[0];
        try (FileInputStream fis = new FileInputStream(file)) {
            InputStream inputStream = new BufferedInputStream(fis);
            buffer = new byte[inputStream.available()];
            int len = inputStream.read(buffer, 0, buffer.length);
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
        response.reset();
        response.setContentType("application/octet-stream");
        response.setCharacterEncoding("utf-8");
        response.addHeader("Content-Disposition", "attachment; filename=\"" + fileInfo.getName() + "\"");
        response.addHeader("Content-Length", String.valueOf(file.length()));
        try (OutputStream out = new BufferedOutputStream(response.getOutputStream())) {
            out.write(buffer);
            out.flush();
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }
}
