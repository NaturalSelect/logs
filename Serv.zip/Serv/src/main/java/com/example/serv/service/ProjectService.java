package com.example.serv.service;

import com.example.serv.entity.Project;

import java.util.List;

public interface ProjectService {
    List<Project> getAll();

    Project insert(Project item);

    void delete(Project item);
}
