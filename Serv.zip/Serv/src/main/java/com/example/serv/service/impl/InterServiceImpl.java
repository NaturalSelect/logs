package com.example.serv.service.impl;

import com.example.serv.dao.InterDao;
import com.example.serv.entity.Inter;
import com.example.serv.service.InterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

/**
 * @author geekYang
 * @version 1.0
 * @since 1.0
 */
@Service
public class InterServiceImpl implements InterService {
    @Autowired
    private InterDao interDao;
    @Override
    public Inter insert(Inter inter) {
        inter.setCreateTime(new Date());
        inter.setUpdateTime(new Date());
        return interDao.save(inter);
    }

    @Override
    public void delete(Integer tid) {
        interDao.deleteById(tid);
    }


    @Override
    public List<Inter> getAll() {
        return interDao.findAll();
    }
}
