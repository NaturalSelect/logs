package com.example.serv.service;

import com.example.serv.entity.Project;
import com.example.serv.entity.ProjectFiles;

import java.util.List;

public interface ProjectFilesService {
    List<ProjectFiles> getAll();

    ProjectFiles insert(ProjectFiles item);

    void delete(ProjectFiles item);
}
