package com.example.serv.service.impl;

import com.example.serv.dao.RoleInfoDao;
import com.example.serv.entity.RoleInfo;
import com.example.serv.service.RoleInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleInfoServiceImpl implements RoleInfoService {
    @Autowired
    private RoleInfoDao roleInfoDao;

    @Override
    public List<RoleInfo> getAll() {
        return roleInfoDao.findAll();
    }

    @Override
    public RoleInfo insert(RoleInfo item) {
        return roleInfoDao.save(item);
    }

    @Override
    public void delete(RoleInfo item) {
        roleInfoDao.delete(item);
    }
}
