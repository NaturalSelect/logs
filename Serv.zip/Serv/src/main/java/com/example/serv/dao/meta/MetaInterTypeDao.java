package com.example.serv.dao.meta;

import com.example.serv.entity.meta.MetaInterType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MetaInterTypeDao extends JpaRepository<MetaInterType,Integer> {
}
