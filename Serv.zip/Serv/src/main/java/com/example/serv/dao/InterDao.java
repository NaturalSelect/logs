package com.example.serv.dao;

import com.example.serv.entity.Inter;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InterDao extends JpaRepository<Inter,Integer> {
}
