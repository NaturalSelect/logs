package com.example.serv.service.impl;

import com.example.serv.dao.ProjectFilesDao;
import com.example.serv.entity.ProjectFiles;
import com.example.serv.service.ProjectFilesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectFilesServiceImpl implements ProjectFilesService {
    @Autowired
    private ProjectFilesDao projectFilesDao;

    @Override
    public List<ProjectFiles> getAll() {
        return projectFilesDao.findAll();
    }

    @Override
    public ProjectFiles insert(ProjectFiles item) {
        return projectFilesDao.save(item);
    }

    @Override
    public void delete(ProjectFiles item) {
        projectFilesDao.delete(item);
    }
}
