package com.example.serv.dao.meta;

import com.example.serv.entity.meta.MetaPermissions;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MetaPermissionsDao extends JpaRepository<MetaPermissions, Integer> {
}
