package com.example.serv.controller;

import com.example.serv.entity.ProjectFiles;
import com.example.serv.service.ProjectFilesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/project_files")
public class ProjectFilesController {
    @Autowired
    private ProjectFilesService projectFilesService;

    @RequestMapping("/all")
    public List<ProjectFiles> getAll() {
        return projectFilesService.getAll();
    }

    //增加一个
    @RequestMapping("/insert")
    public ProjectFiles insert(@RequestBody ProjectFiles item) {
        return projectFilesService.insert(item);
    }

    //删除一个
    @RequestMapping("/delete")
    public String delete(@RequestBody ProjectFiles item) {
        projectFilesService.delete(item);
        return "";
    }

    //修改一个
    @RequestMapping("/update")
    public ProjectFiles update(@RequestBody ProjectFiles item) {
        //增改是同一个逻辑
        return insert(item);
    }
}
