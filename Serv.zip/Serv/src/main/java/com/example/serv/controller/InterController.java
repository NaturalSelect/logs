package com.example.serv.controller;

import com.example.serv.entity.Group;
import com.example.serv.entity.Inter;
import com.example.serv.service.GroupService;
import com.example.serv.service.InterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping("/inter")
public class InterController {
    @Autowired
    private InterService interService;

    //查询所有
    @RequestMapping("/all")
    public List<Inter> getAll() {
        return interService.getAll();
    }

    //增加一个
    @RequestMapping("/insert")
    public Inter insert(@RequestBody Inter inter) {
        return interService.insert(inter);
    }

    //删除一个
    @RequestMapping("/delete")
    public String delete(@RequestBody Inter inter) {
        interService.delete(inter.getTid());
        return "";
    }

    //修改一个
    @RequestMapping("/update")
    public Inter update(@RequestBody Inter inter) {
        //增改是同一个逻辑
        return insert(inter);
    }
}
