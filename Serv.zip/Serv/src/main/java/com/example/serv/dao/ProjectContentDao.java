package com.example.serv.dao;

import com.example.serv.entity.ProjectContent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectContentDao extends JpaRepository<ProjectContent,Integer> {
}
