package com.example.serv.service;

import com.example.serv.entity.RoleInfo;

import java.util.List;

public interface RoleInfoService {
    List<RoleInfo> getAll();

    RoleInfo insert(RoleInfo item);

    void delete(RoleInfo item);
}
