package com.example.serv.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity(name = "role_tb")
public class Role {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "uid")
    Integer uid;
    @Column(name = "phone")
    String phone;
    @Column(name = "nickname")
    String nickname;
    @Column(name = "token")
    String token;
    @Column(name = "belong")
    Integer belong;//meta_group_type
}
