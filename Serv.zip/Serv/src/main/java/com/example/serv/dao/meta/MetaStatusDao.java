package com.example.serv.dao.meta;

import com.example.serv.entity.meta.MetaStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MetaStatusDao extends JpaRepository<MetaStatus, Integer> {
}
