package com.example.serv.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity(name = "role_info_tb")
public class RoleInfo {
    @Id
    @Column(name = "uid")
    Integer uid;
    @Column(name = "avatar_url")
    String avatarUrl;
    @Column(name = "sex")
    Integer sex;
    @Column(name = "introduction")
    String introduction;
    @Column(name = "email")
    String email;
    @Column(name = "whoami")
    String whoami;
    @Column(name = "status")
    Integer status;
}
