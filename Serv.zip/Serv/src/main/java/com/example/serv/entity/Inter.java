package com.example.serv.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Data
@Entity(name = "inter_tb")
public class Inter {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tid")
    private Integer tid;

    /**
     * 实习类型标识
     */
    @Column(name = "inter_type")
    private String interType;

    /**
     * 实习岗位名称
     */
    @Column(name = "inter_name")
    private String interName;

    /**
     * 所属行业
     */
    @Column(name = "industry")
    private String industry;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    private Date createTime;

    /**
     * 修改时间
     */
    @Column(name = "update_time")
    private Date updateTime;

}
