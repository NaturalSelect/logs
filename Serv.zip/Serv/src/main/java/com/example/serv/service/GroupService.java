package com.example.serv.service;

import com.example.serv.entity.Group;

import java.util.List;

public interface GroupService {
    List<Group> getAll();

    Group insert(Group group);

    void delete(Group group);
}
