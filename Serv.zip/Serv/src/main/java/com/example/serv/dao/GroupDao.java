package com.example.serv.dao;

import com.example.serv.entity.Group;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GroupDao extends JpaRepository<Group,Integer> {
}
