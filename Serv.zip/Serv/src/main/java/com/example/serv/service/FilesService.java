package com.example.serv.service;

import com.example.serv.entity.Files;

import java.util.List;

public interface FilesService {
    List<Files> getAllFiles();

    Files getFileByUrl(String url);

    Files saveFile(Files files);
}
