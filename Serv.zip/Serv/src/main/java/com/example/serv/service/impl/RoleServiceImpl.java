package com.example.serv.service.impl;

import com.example.serv.dao.RoleDao;
import com.example.serv.entity.Role;
import com.example.serv.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceImpl implements RoleService {
    @Autowired
    private RoleDao roleDao;

    @Override
    public List<Role> getAll() {
        return roleDao.findAll();
    }

    @Override
    public Role insert(Role item) {
        return roleDao.save(item);
    }

    @Override
    public void delete(Role item) {
        roleDao.delete(item);
    }

    @Override
    public Role findByPhone(String phone) {
        return roleDao.findByPhone(phone);
    }
}
