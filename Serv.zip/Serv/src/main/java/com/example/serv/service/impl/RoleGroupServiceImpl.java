package com.example.serv.service.impl;

import com.example.serv.dao.RoleGroupDao;
import com.example.serv.entity.RoleGroup;
import com.example.serv.service.RoleGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleGroupServiceImpl implements RoleGroupService {
    @Autowired
    private RoleGroupDao roleGroupDao;

    @Override
    public List<RoleGroup> getAll() {
        return roleGroupDao.findAll();
    }

    @Override
    public RoleGroup insert(RoleGroup item) {
        return roleGroupDao.save(item);
    }

    @Override
    public void delete(RoleGroup item) {
        roleGroupDao.delete(item);
    }
}
