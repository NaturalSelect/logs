package com.example.serv.service;

import com.example.serv.entity.ProjectContent;

import java.util.List;

public interface ProjectContentService {
    List<ProjectContent> getAll();

    ProjectContent insert(ProjectContent projectContent);

    void delete(ProjectContent projectContent);
}
