package com.example.serv.dao;

import com.example.serv.entity.RoleGroup;
import com.example.serv.entity.UPKs;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleGroupDao extends JpaRepository<RoleGroup, UPKs.RoleGroupUPK> {
}
